# InlineResponse2004

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**s3Path** | **String** |  |  [optional]
**clusterLabel** | **Integer** |  |  [optional]
**visualizationVector** | [**List&lt;BigDecimal&gt;**](BigDecimal.md) |  |  [optional]
