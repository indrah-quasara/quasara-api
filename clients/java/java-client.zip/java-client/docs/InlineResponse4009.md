# InlineResponse4009

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**error** | **String** | Description of the error that occurred due to invalid input or the job being in a non-pausable state. |  [optional]
