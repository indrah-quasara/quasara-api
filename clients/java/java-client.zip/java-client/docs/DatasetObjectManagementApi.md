# DatasetObjectManagementApi

All URIs are relative to */*

Method | HTTP request | Description
------------- | ------------- | -------------
[**detectObjects**](DatasetObjectManagementApi.md#detectObjects) | **POST** /detect-objects | Initiate Object Detection Job
[**getTags**](DatasetObjectManagementApi.md#getTags) | **GET** /tags | Retrieve Tags
[**listDatasets**](DatasetObjectManagementApi.md#listDatasets) | **GET** /datasets | Retrieve List of Datasets
[**listModels**](DatasetObjectManagementApi.md#listModels) | **GET** /models | Retrieve List of Models
[**updateTags**](DatasetObjectManagementApi.md#updateTags) | **POST** /update-tags | Update Tags for Dataset

<a name="detectObjects"></a>
# **detectObjects**
> InlineResponse201 detectObjects(body, authorization, accept, contentType)

Initiate Object Detection Job

This endpoint allows users to start a job for object detection. Users can specify either &#x60;dataset_id&#x60; or &#x60;search_result_id&#x60;.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.DatasetObjectManagementApi;


DatasetObjectManagementApi apiInstance = new DatasetObjectManagementApi();
DetectobjectsBody body = new DetectobjectsBody(); // DetectobjectsBody | Request to initiate an object detection job.
String authorization = "authorization_example"; // String | 
String accept = "application/json"; // String | 
String contentType = "application/json"; // String | 
try {
    InlineResponse201 result = apiInstance.detectObjects(body, authorization, accept, contentType);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling DatasetObjectManagementApi#detectObjects");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**DetectobjectsBody**](DetectobjectsBody.md)| Request to initiate an object detection job. |
 **authorization** | **String**|  |
 **accept** | **String**|  | [default to application/json]
 **contentType** | **String**|  | [default to application/json]

### Return type

[**InlineResponse201**](InlineResponse201.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="getTags"></a>
# **getTags**
> InlineResponse2006 getTags(authorization, accept)

Retrieve Tags

This endpoint allows users to retrieve a list of tags along with their associated resources and model labels.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.DatasetObjectManagementApi;


DatasetObjectManagementApi apiInstance = new DatasetObjectManagementApi();
String authorization = "authorization_example"; // String | 
String accept = "application/json"; // String | 
try {
    InlineResponse2006 result = apiInstance.getTags(authorization, accept);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling DatasetObjectManagementApi#getTags");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **String**|  |
 **accept** | **String**|  | [default to application/json]

### Return type

[**InlineResponse2006**](InlineResponse2006.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="listDatasets"></a>
# **listDatasets**
> InlineResponse2007 listDatasets(authorization, accept)

Retrieve List of Datasets

This endpoint allows users to retrieve a list of available datasets.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.DatasetObjectManagementApi;


DatasetObjectManagementApi apiInstance = new DatasetObjectManagementApi();
String authorization = "authorization_example"; // String | 
String accept = "application/json"; // String | 
try {
    InlineResponse2007 result = apiInstance.listDatasets(authorization, accept);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling DatasetObjectManagementApi#listDatasets");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **String**|  |
 **accept** | **String**|  | [default to application/json]

### Return type

[**InlineResponse2007**](InlineResponse2007.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="listModels"></a>
# **listModels**
> InlineResponse2008 listModels(authorization, accept)

Retrieve List of Models

This endpoint allows users to retrieve a list of available models.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.DatasetObjectManagementApi;


DatasetObjectManagementApi apiInstance = new DatasetObjectManagementApi();
String authorization = "authorization_example"; // String | 
String accept = "application/json"; // String | 
try {
    InlineResponse2008 result = apiInstance.listModels(authorization, accept);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling DatasetObjectManagementApi#listModels");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **String**|  |
 **accept** | **String**|  | [default to application/json]

### Return type

[**InlineResponse2008**](InlineResponse2008.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="updateTags"></a>
# **updateTags**
> InlineResponse2011 updateTags(body, authorization, accept, contentType)

Update Tags for Dataset

This endpoint allows users to update the tags associated with a specific dataset.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.DatasetObjectManagementApi;


DatasetObjectManagementApi apiInstance = new DatasetObjectManagementApi();
UpdatetagsBody body = new UpdatetagsBody(); // UpdatetagsBody | 
String authorization = "authorization_example"; // String | 
String accept = "application/json"; // String | 
String contentType = "application/json"; // String | 
try {
    InlineResponse2011 result = apiInstance.updateTags(body, authorization, accept, contentType);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling DatasetObjectManagementApi#updateTags");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**UpdatetagsBody**](UpdatetagsBody.md)|  |
 **authorization** | **String**|  |
 **accept** | **String**|  | [default to application/json]
 **contentType** | **String**|  | [default to application/json]

### Return type

[**InlineResponse2011**](InlineResponse2011.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

