# InlineResponse2002

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**searchResultsId** | **String** |  |  [optional]
**results** | **List&lt;Object&gt;** |  |  [optional]
