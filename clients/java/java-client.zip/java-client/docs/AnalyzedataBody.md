# AnalyzedataBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**tagId** | **String** | The unique identifier for the tag. |  [optional]
**analyticType** | **String** | Type of the data analytics (clustering, similarity, or outlier). |  [optional]
**algorithm** | **String** | The main algorithm to be used for the process. |  [optional]
**dimensionalityReductionAlgorithm** | **String** | The algorithm to be used for dimensionality reduction. |  [optional]
**dimensionSize** | **Integer** | The size of the dimension for dimensionality reduction. |  [optional]
**scoreThreshold** | **Float** | Threshold for clustering and similarity score. |  [optional]
**contamination** | **Float** | Contamination for the outlier detection algorithm. |  [optional]
