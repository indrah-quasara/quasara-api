# InlineResponse4008

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**error** | **String** | Description of the error that occurred due to invalid input. |  [optional]
