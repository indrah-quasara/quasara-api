# JobManagementAuthorisationApi

All URIs are relative to */*

Method | HTTP request | Description
------------- | ------------- | -------------
[**analyzeData**](JobManagementAuthorisationApi.md#analyzeData) | **POST** /analyze-data | Analyze Data
[**checkJobStatus**](JobManagementAuthorisationApi.md#checkJobStatus) | **POST** /job-status | Check Job Status
[**getUserJobs**](JobManagementAuthorisationApi.md#getUserJobs) | **GET** /jobs | Fetch User&#x27;s Jobs
[**login**](JobManagementAuthorisationApi.md#login) | **POST** /login | Login to get API Key
[**pauseJob**](JobManagementAuthorisationApi.md#pauseJob) | **PUT** /pause-job | Pause a Running Job

<a name="analyzeData"></a>
# **analyzeData**
> InlineResponse2009 analyzeData(body)

Analyze Data

This endpoint allows users to initiate clustering, similarity, and outlier detection for a specified tag.  If the data analytics process has already been completed for the given tag, a message will be returned,  and users can use the &#x60;/fetch-data-analytics&#x60; endpoint to retrieve the results. Otherwise, the API creates  a job and returns a job ID. 

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.JobManagementAuthorisationApi;


JobManagementAuthorisationApi apiInstance = new JobManagementAuthorisationApi();
AnalyzedataBody body = new AnalyzedataBody(); // AnalyzedataBody | 
try {
    InlineResponse2009 result = apiInstance.analyzeData(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling JobManagementAuthorisationApi#analyzeData");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**AnalyzedataBody**](AnalyzedataBody.md)|  |

### Return type

[**InlineResponse2009**](InlineResponse2009.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="checkJobStatus"></a>
# **checkJobStatus**
> InlineResponse20010 checkJobStatus(body, authorization, accept, contentType)

Check Job Status

This endpoint allows users to check the current status of a specific job.  By providing the job ID, the API returns the job&#x27;s status, including the processing stage and additional details. 

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.JobManagementAuthorisationApi;


JobManagementAuthorisationApi apiInstance = new JobManagementAuthorisationApi();
JobstatusBody body = new JobstatusBody(); // JobstatusBody | 
String authorization = "authorization_example"; // String | 
String accept = "application/json"; // String | 
String contentType = "application/json"; // String | 
try {
    InlineResponse20010 result = apiInstance.checkJobStatus(body, authorization, accept, contentType);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling JobManagementAuthorisationApi#checkJobStatus");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**JobstatusBody**](JobstatusBody.md)|  |
 **authorization** | **String**|  |
 **accept** | **String**|  | [default to application/json]
 **contentType** | **String**|  | [default to application/json]

### Return type

[**InlineResponse20010**](InlineResponse20010.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="getUserJobs"></a>
# **getUserJobs**
> List&lt;InlineResponse20011&gt; getUserJobs(authorization, accept)

Fetch User&#x27;s Jobs

This endpoint retrieves a list of jobs associated with the authenticated user.  For each job, details such as job ID, the dataset it is linked to, current status,  a message, and the timestamp of creation or last update are included. 

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.JobManagementAuthorisationApi;


JobManagementAuthorisationApi apiInstance = new JobManagementAuthorisationApi();
String authorization = "authorization_example"; // String | 
String accept = "application/json"; // String | 
try {
    List<InlineResponse20011> result = apiInstance.getUserJobs(authorization, accept);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling JobManagementAuthorisationApi#getUserJobs");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **String**|  |
 **accept** | **String**|  | [default to application/json]

### Return type

[**List&lt;InlineResponse20011&gt;**](InlineResponse20011.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="login"></a>
# **login**
> InlineResponse20013 login(body)

Login to get API Key

This endpoint allows users to obtain an API key by providing their email and password for authentication. 

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.JobManagementAuthorisationApi;


JobManagementAuthorisationApi apiInstance = new JobManagementAuthorisationApi();
LoginBody body = new LoginBody(); // LoginBody | 
try {
    InlineResponse20013 result = apiInstance.login(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling JobManagementAuthorisationApi#login");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**LoginBody**](LoginBody.md)|  |

### Return type

[**InlineResponse20013**](InlineResponse20013.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="pauseJob"></a>
# **pauseJob**
> InlineResponse20012 pauseJob(body, authorization, accept, contentType)

Pause a Running Job

This endpoint allows users to pause a currently running job by updating its status to \&quot;STOPPING_PAUSED\&quot; or \&quot;PAUSED\&quot;.  If the job is already completed, paused, or in a non-pausable state, the current status will be returned without making any changes. 

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.JobManagementAuthorisationApi;


JobManagementAuthorisationApi apiInstance = new JobManagementAuthorisationApi();
PausejobBody body = new PausejobBody(); // PausejobBody | 
String authorization = "authorization_example"; // String | 
String accept = "application/json"; // String | 
String contentType = "application/json"; // String | 
try {
    InlineResponse20012 result = apiInstance.pauseJob(body, authorization, accept, contentType);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling JobManagementAuthorisationApi#pauseJob");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**PausejobBody**](PausejobBody.md)|  |
 **authorization** | **String**|  |
 **accept** | **String**|  | [default to application/json]
 **contentType** | **String**|  | [default to application/json]

### Return type

[**InlineResponse20012**](InlineResponse20012.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

