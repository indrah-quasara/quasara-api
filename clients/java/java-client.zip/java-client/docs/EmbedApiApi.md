# EmbedApiApi

All URIs are relative to */*

Method | HTTP request | Description
------------- | ------------- | -------------
[**defineDataset**](EmbedApiApi.md#defineDataset) | **POST** /define-dataset | Define a New Dataset
[**downloadEmbeddings**](EmbedApiApi.md#downloadEmbeddings) | **POST** /download-embeddings | Download Embeddings for a Tag
[**extractEmbeddings**](EmbedApiApi.md#extractEmbeddings) | **POST** /extract-embeddings | Extract Embeddings from Dataset
[**extractEntities**](EmbedApiApi.md#extractEntities) | **POST** /entity_extraction | Extract Entities from Dataset
[**getModels**](EmbedApiApi.md#getModels) | **GET** /llm_models | Get Available LLM Models
[**getSession**](EmbedApiApi.md#getSession) | **GET** /session/{session_id} | Get Session Data
[**getSessionIds**](EmbedApiApi.md#getSessionIds) | **GET** /session_ids | Get User&#x27;s Session IDs
[**retrieveEntityExtractionData**](EmbedApiApi.md#retrieveEntityExtractionData) | **POST** /retrieve-entity-extraction-data/ | Retrieve Entity Extraction Data
[**sendMessage**](EmbedApiApi.md#sendMessage) | **POST** /message | Send Message for RAG Processing
[**uploadDataset**](EmbedApiApi.md#uploadDataset) | **POST** /upload-dataset | Upload a Dataset ZIP File

<a name="defineDataset"></a>
# **defineDataset**
> InlineResponse200 defineDataset(body, authorization, accept, contentType)

Define a New Dataset

This endpoint allows users to define a new dataset.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.EmbedApiApi;


EmbedApiApi apiInstance = new EmbedApiApi();
DefinedatasetBody body = new DefinedatasetBody(); // DefinedatasetBody | Define a new dataset by providing necessary details.
String authorization = "authorization_example"; // String | 
String accept = "application/json"; // String | 
String contentType = "application/json"; // String | 
try {
    InlineResponse200 result = apiInstance.defineDataset(body, authorization, accept, contentType);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling EmbedApiApi#defineDataset");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**DefinedatasetBody**](DefinedatasetBody.md)| Define a new dataset by providing necessary details. |
 **authorization** | **String**|  |
 **accept** | **String**|  | [default to application/json]
 **contentType** | **String**|  | [default to application/json]

### Return type

[**InlineResponse200**](InlineResponse200.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="downloadEmbeddings"></a>
# **downloadEmbeddings**
> InlineResponse201 downloadEmbeddings(body, authorization, accept, contentType)

Download Embeddings for a Tag

This endpoint allows users to download embeddings associated with a specific tag.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.EmbedApiApi;


EmbedApiApi apiInstance = new EmbedApiApi();
DownloadembeddingsBody body = new DownloadembeddingsBody(); // DownloadembeddingsBody | Request to download embeddings for a specific tag.
String authorization = "authorization_example"; // String | 
String accept = "application/json"; // String | 
String contentType = "application/json"; // String | 
try {
    InlineResponse201 result = apiInstance.downloadEmbeddings(body, authorization, accept, contentType);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling EmbedApiApi#downloadEmbeddings");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**DownloadembeddingsBody**](DownloadembeddingsBody.md)| Request to download embeddings for a specific tag. |
 **authorization** | **String**|  |
 **accept** | **String**|  | [default to application/json]
 **contentType** | **String**|  | [default to application/json]

### Return type

[**InlineResponse201**](InlineResponse201.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="extractEmbeddings"></a>
# **extractEmbeddings**
> InlineResponse201 extractEmbeddings(body, authorization, accept, contentType)

Extract Embeddings from Dataset

This endpoint allows users to extract embeddings from a specified dataset using a given model and configuration options.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.EmbedApiApi;


EmbedApiApi apiInstance = new EmbedApiApi();
ExtractembeddingsBody body = new ExtractembeddingsBody(); // ExtractembeddingsBody | Request to extract embeddings from the dataset.
String authorization = "authorization_example"; // String | 
String accept = "application/json"; // String | 
String contentType = "application/json"; // String | 
try {
    InlineResponse201 result = apiInstance.extractEmbeddings(body, authorization, accept, contentType);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling EmbedApiApi#extractEmbeddings");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**ExtractembeddingsBody**](ExtractembeddingsBody.md)| Request to extract embeddings from the dataset. |
 **authorization** | **String**|  |
 **accept** | **String**|  | [default to application/json]
 **contentType** | **String**|  | [default to application/json]

### Return type

[**InlineResponse201**](InlineResponse201.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="extractEntities"></a>
# **extractEntities**
> InlineResponse201 extractEntities(body, authorization, accept, contentType)

Extract Entities from Dataset

This endpoint allows users to extract entities from a specified dataset using a given model.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.EmbedApiApi;


EmbedApiApi apiInstance = new EmbedApiApi();
EntityExtractionBody body = new EntityExtractionBody(); // EntityExtractionBody | Request to extract entities from the dataset.
String authorization = "authorization_example"; // String | 
String accept = "application/json"; // String | 
String contentType = "application/json"; // String | 
try {
    InlineResponse201 result = apiInstance.extractEntities(body, authorization, accept, contentType);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling EmbedApiApi#extractEntities");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**EntityExtractionBody**](EntityExtractionBody.md)| Request to extract entities from the dataset. |
 **authorization** | **String**|  |
 **accept** | **String**|  | [default to application/json]
 **contentType** | **String**|  | [default to application/json]

### Return type

[**InlineResponse201**](InlineResponse201.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="getModels"></a>
# **getModels**
> InlineResponse20016 getModels(authorization, accept)

Get Available LLM Models

This endpoint returns a list of available language models that can be used for processing.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.EmbedApiApi;


EmbedApiApi apiInstance = new EmbedApiApi();
String authorization = "authorization_example"; // String | 
String accept = "application/json"; // String | 
try {
    InlineResponse20016 result = apiInstance.getModels(authorization, accept);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling EmbedApiApi#getModels");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **String**|  |
 **accept** | **String**|  | [default to application/json]

### Return type

[**InlineResponse20016**](InlineResponse20016.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="getSession"></a>
# **getSession**
> InlineResponse20017 getSession(sessionId, authorization, accept)

Get Session Data

This endpoint retrieves session data for a specific session ID, with any MongoDB ObjectIds converted to strings.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.EmbedApiApi;


EmbedApiApi apiInstance = new EmbedApiApi();
String sessionId = "sessionId_example"; // String | 
String authorization = "authorization_example"; // String | 
String accept = "application/json"; // String | 
try {
    InlineResponse20017 result = apiInstance.getSession(sessionId, authorization, accept);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling EmbedApiApi#getSession");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sessionId** | **String**|  |
 **authorization** | **String**|  |
 **accept** | **String**|  | [default to application/json]

### Return type

[**InlineResponse20017**](InlineResponse20017.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="getSessionIds"></a>
# **getSessionIds**
> InlineResponse20018 getSessionIds(authorization, accept)

Get User&#x27;s Session IDs

This endpoint retrieves all session IDs associated with the authenticated user.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.EmbedApiApi;


EmbedApiApi apiInstance = new EmbedApiApi();
String authorization = "authorization_example"; // String | 
String accept = "application/json"; // String | 
try {
    InlineResponse20018 result = apiInstance.getSessionIds(authorization, accept);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling EmbedApiApi#getSessionIds");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **String**|  |
 **accept** | **String**|  | [default to application/json]

### Return type

[**InlineResponse20018**](InlineResponse20018.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="retrieveEntityExtractionData"></a>
# **retrieveEntityExtractionData**
> InlineResponse20014 retrieveEntityExtractionData(body, authorization, accept, contentType)

Retrieve Entity Extraction Data

This endpoint allows users to retrieve previously extracted entity data with pagination.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.EmbedApiApi;


EmbedApiApi apiInstance = new EmbedApiApi();
RetrieveentityextractiondataBody body = new RetrieveentityextractiondataBody(); // RetrieveentityextractiondataBody | Request to retrieve entity extraction data.
String authorization = "authorization_example"; // String | 
String accept = "application/json"; // String | 
String contentType = "application/json"; // String | 
try {
    InlineResponse20014 result = apiInstance.retrieveEntityExtractionData(body, authorization, accept, contentType);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling EmbedApiApi#retrieveEntityExtractionData");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**RetrieveentityextractiondataBody**](RetrieveentityextractiondataBody.md)| Request to retrieve entity extraction data. |
 **authorization** | **String**|  |
 **accept** | **String**|  | [default to application/json]
 **contentType** | **String**|  | [default to application/json]

### Return type

[**InlineResponse20014**](InlineResponse20014.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="sendMessage"></a>
# **sendMessage**
> InlineResponse20015 sendMessage(body, authorization, accept, contentType)

Send Message for RAG Processing

This endpoint allows users to send a message for processing using Retrieval Augmented Generation (RAG).

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.EmbedApiApi;


EmbedApiApi apiInstance = new EmbedApiApi();
MessageBody body = new MessageBody(); // MessageBody | Request to process a user message using RAG.
String authorization = "authorization_example"; // String | 
String accept = "application/json"; // String | 
String contentType = "application/json"; // String | 
try {
    InlineResponse20015 result = apiInstance.sendMessage(body, authorization, accept, contentType);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling EmbedApiApi#sendMessage");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**MessageBody**](MessageBody.md)| Request to process a user message using RAG. |
 **authorization** | **String**|  |
 **accept** | **String**|  | [default to application/json]
 **contentType** | **String**|  | [default to application/json]

### Return type

[**InlineResponse20015**](InlineResponse20015.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="uploadDataset"></a>
# **uploadDataset**
> InlineResponse2001 uploadDataset(datasetZipFile, datasetId, authorization, accept, contentType)

Upload a Dataset ZIP File

This endpoint allows users to upload a ZIP file containing a dataset to a specific dataset ID.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.EmbedApiApi;


EmbedApiApi apiInstance = new EmbedApiApi();
byte[] datasetZipFile = B; // byte[] | 
String datasetId = "datasetId_example"; // String | 
String authorization = "authorization_example"; // String | 
String accept = "application/json"; // String | 
String contentType = "multipart/form-data"; // String | 
try {
    InlineResponse2001 result = apiInstance.uploadDataset(datasetZipFile, datasetId, authorization, accept, contentType);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling EmbedApiApi#uploadDataset");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **datasetZipFile** | **byte[]**|  |
 **datasetId** | **String**|  |
 **authorization** | **String**|  |
 **accept** | **String**|  | [default to application/json]
 **contentType** | **String**|  | [default to multipart/form-data]

### Return type

[**InlineResponse2001**](InlineResponse2001.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: multipart/form-data
 - **Accept**: application/json

