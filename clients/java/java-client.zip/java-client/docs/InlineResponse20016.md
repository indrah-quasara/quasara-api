# InlineResponse20016

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**models** | **List&lt;String&gt;** | List of available model names |  [optional]
