# ExtractembeddingsBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**datasetId** | **String** | The unique identifier for the dataset. |  [optional]
**modelName** | **String** | (Optional) The name of the model to use for processing the dataset. Format: model_name:version. |  [optional]
**splitMethod** | **String** | (Optional) The method for splitting the dataset. If not provided, the default method will be used. |  [optional]
**processSplits** | **Boolean** | (Optional) Flag to indicate if splits should be processed. Defaults to true. |  [optional]
**processImages** | **Boolean** | (Optional) Flag to indicate if images should be processed. Defaults to true. |  [optional]
**batchSize** | **Integer** | (Optional) The number of items to process in each batch. |  [optional]
**logToMail** | **Boolean** | (Optional) Flag to receive email notifications about the job status. |  [optional]
