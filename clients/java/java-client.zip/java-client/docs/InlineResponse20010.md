# InlineResponse20010

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**jobId** | **String** | The ID of the job being checked. |  [optional]
**status** | **String** | The current status of the job. |  [optional]
**message** | **String** | A message providing additional details about the job&#x27;s current state. |  [optional]
**bucketIdx** | **Integer** | The index of the bucket currently being processed, if applicable. |  [optional]
**batch** | **Integer** | The index of the batch currently being processed, if applicable. |  [optional]
**percentage** | **Object** |  |  [optional]
**avgBatchTime** | **Float** | Average batch time. |  [optional]
