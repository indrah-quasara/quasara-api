# LoginBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**email** | **String** | The email of the user. |  [optional]
**password** | **String** | The password of the user. |  [optional]
