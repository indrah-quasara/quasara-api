# InlineResponse20011

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**jobId** | **String** | The unique identifier of the job. |  [optional]
**datasetId** | **String** | The unique identifier of the dataset associated with the job. |  [optional]
**status** | **String** | The current status of the job. |  [optional]
**message** | **String** | A message associated with the job status. |  [optional]
**time** | [**OffsetDateTime**](OffsetDateTime.md) | The timestamp of the job creation or last update. |  [optional]
