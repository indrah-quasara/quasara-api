# EntityExtractionBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**datasetId** | **String** | The unique identifier for the dataset. | 
**documentDomain** | **String** | The domain of documents to process. Must be one of the supported domains. | 
**modelName** | **String** | The name of the model to be used for processing the dataset. | 
