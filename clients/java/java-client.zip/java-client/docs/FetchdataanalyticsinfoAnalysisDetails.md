# FetchdataanalyticsinfoAnalysisDetails

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**totalClusters** | **String** |  |  [optional]
**totalOutliers** | **Integer** |  |  [optional]
**algorithmTimeTaken** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**meanClusterSize** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
