# RetrieveobjectdetectiondataBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**jobId** | **String** | The unique identifier for the job. This ID corresponds to a specific job or operation being processed. |  [optional]
**page** | **Integer** | The page number to retrieve for paginated results. |  [optional]
**pageSize** | **Integer** | The number of items to include per page in the paginated results. |  [optional]
