# InlineResponse2006

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**results** | **List&lt;Object&gt;** |  |  [optional]
