# InlineResponse4041

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**error** | **String** | Description of the error that occurred because the job was not found. |  [optional]
