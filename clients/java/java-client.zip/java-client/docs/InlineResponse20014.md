# InlineResponse20014

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**currentPage** | **Integer** |  |  [optional]
**pageSize** | **Integer** |  |  [optional]
**totalCount** | **Integer** |  |  [optional]
**totalPages** | **Integer** |  |  [optional]
**results** | **List&lt;Object&gt;** | Array of extracted entity data objects |  [optional]
