# DetectobjectsBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**modelName** | **String** | The name of the model to use for embedding extraction. |  [optional]
**labels** | **List&lt;String&gt;** | List of labels to detect. |  [optional]
**datasetId** | **String** | The ID of the dataset to extract embeddings from. |  [optional]
**batchSize** | **Integer** | Batch size for processing images. |  [optional]
**logToMail** | **Boolean** | Whether to log errors to email. |  [optional]
**searchResultsId** | **String** | Optional ID of the search results. |  [optional]
