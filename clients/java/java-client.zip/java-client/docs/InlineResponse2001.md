# InlineResponse2001

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**message** | **String** |  |  [optional]
**skippedFiles** | **List&lt;String&gt;** |  |  [optional]
