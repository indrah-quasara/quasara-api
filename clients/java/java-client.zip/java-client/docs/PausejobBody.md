# PausejobBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**jobId** | **String** | The unique identifier of the job to be paused. |  [optional]
