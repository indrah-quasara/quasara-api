# InlineResponse40013

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**error** | **String** |  |  [optional]
