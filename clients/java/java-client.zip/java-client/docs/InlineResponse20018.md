# InlineResponse20018

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sessions** | **List&lt;String&gt;** | List of session IDs belonging to the user |  [optional]
