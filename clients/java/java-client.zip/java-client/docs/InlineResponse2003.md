# InlineResponse2003

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**dataAnalyticsId** | **String** |  |  [optional]
**type** | **String** |  |  [optional]
**algorithm** | **String** |  |  [optional]
**isCompleted** | **Boolean** |  |  [optional]
**dimensionSize** | **Integer** |  |  [optional]
**dimensionalityReductionAlgorithm** | **String** |  |  [optional]
**scoreThreshold** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**contamination** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**analysisDetails** | [**List&lt;FetchdataanalyticsinfoAnalysisDetails&gt;**](FetchdataanalyticsinfoAnalysisDetails.md) |  |  [optional]
