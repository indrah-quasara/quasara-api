# RetrieveentityextractiondataBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**jobId** | **String** | The ID of the job whose entity extraction data is being queried. | 
**page** | **Integer** | The page number for pagination (min: 1). |  [optional]
**pageSize** | **Integer** | The number of items per page (min: 1, max: 50). |  [optional]
