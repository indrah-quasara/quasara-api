# InlineResponse20015

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**answer** | **String** |  |  [optional]
**conversationId** | **String** |  |  [optional]
