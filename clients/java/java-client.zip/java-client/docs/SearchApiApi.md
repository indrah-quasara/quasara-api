# SearchApiApi

All URIs are relative to */*

Method | HTTP request | Description
------------- | ------------- | -------------
[**fetchDataAnalyticsInfo**](SearchApiApi.md#fetchDataAnalyticsInfo) | **POST** /fetch-data-analytics-info | Fetch Data Analytics Information
[**fetchDataAnalyticsResults**](SearchApiApi.md#fetchDataAnalyticsResults) | **POST** /fetch-data-analytics-results | Fetch Data Analytics Results
[**retrieveObjectDetectionData**](SearchApiApi.md#retrieveObjectDetectionData) | **POST** /retrieve-object-detection-data | Retrieve Object Detection Data
[**searchDataset**](SearchApiApi.md#searchDataset) | **POST** /search | Search the Dataset

<a name="fetchDataAnalyticsInfo"></a>
# **fetchDataAnalyticsInfo**
> List&lt;InlineResponse2003&gt; fetchDataAnalyticsInfo(body, authorization, accept, contentType)

Fetch Data Analytics Information

This endpoint allows users to retrieve the data analytics information for a specified tag.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.SearchApiApi;


SearchApiApi apiInstance = new SearchApiApi();
FetchdataanalyticsinfoBody body = new FetchdataanalyticsinfoBody(); // FetchdataanalyticsinfoBody | Request to fetch the data analytics information for the specified tag.
String authorization = "authorization_example"; // String | 
String accept = "application/json"; // String | 
String contentType = "application/json"; // String | 
try {
    List<InlineResponse2003> result = apiInstance.fetchDataAnalyticsInfo(body, authorization, accept, contentType);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SearchApiApi#fetchDataAnalyticsInfo");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**FetchdataanalyticsinfoBody**](FetchdataanalyticsinfoBody.md)| Request to fetch the data analytics information for the specified tag. |
 **authorization** | **String**|  |
 **accept** | **String**|  | [default to application/json]
 **contentType** | **String**|  | [default to application/json]

### Return type

[**List&lt;InlineResponse2003&gt;**](InlineResponse2003.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="fetchDataAnalyticsResults"></a>
# **fetchDataAnalyticsResults**
> List&lt;InlineResponse2004&gt; fetchDataAnalyticsResults(body, authorization, accept, contentType)

Fetch Data Analytics Results

This endpoint allows users to fetch the results of the data analytics process.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.SearchApiApi;


SearchApiApi apiInstance = new SearchApiApi();
FetchdataanalyticsresultsBody body = new FetchdataanalyticsresultsBody(); // FetchdataanalyticsresultsBody | Request to fetch the results for the specified data analytics.
String authorization = "authorization_example"; // String | 
String accept = "application/json"; // String | 
String contentType = "application/json"; // String | 
try {
    List<InlineResponse2004> result = apiInstance.fetchDataAnalyticsResults(body, authorization, accept, contentType);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SearchApiApi#fetchDataAnalyticsResults");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**FetchdataanalyticsresultsBody**](FetchdataanalyticsresultsBody.md)| Request to fetch the results for the specified data analytics. |
 **authorization** | **String**|  |
 **accept** | **String**|  | [default to application/json]
 **contentType** | **String**|  | [default to application/json]

### Return type

[**List&lt;InlineResponse2004&gt;**](InlineResponse2004.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="retrieveObjectDetectionData"></a>
# **retrieveObjectDetectionData**
> InlineResponse2005 retrieveObjectDetectionData(body, authorization, accept, contentType)

Retrieve Object Detection Data

This endpoint allows users to retrieve object detection data for a specific job.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.SearchApiApi;


SearchApiApi apiInstance = new SearchApiApi();
RetrieveobjectdetectiondataBody body = new RetrieveobjectdetectiondataBody(); // RetrieveobjectdetectiondataBody | Request to fetch object detection data for a specified job.
String authorization = "authorization_example"; // String | 
String accept = "application/json"; // String | 
String contentType = "application/json"; // String | 
try {
    InlineResponse2005 result = apiInstance.retrieveObjectDetectionData(body, authorization, accept, contentType);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SearchApiApi#retrieveObjectDetectionData");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**RetrieveobjectdetectiondataBody**](RetrieveobjectdetectiondataBody.md)| Request to fetch object detection data for a specified job. |
 **authorization** | **String**|  |
 **accept** | **String**|  | [default to application/json]
 **contentType** | **String**|  | [default to application/json]

### Return type

[**InlineResponse2005**](InlineResponse2005.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="searchDataset"></a>
# **searchDataset**
> InlineResponse2002 searchDataset(body, authorization, accept, contentType)

Search the Dataset

This endpoint allows users to search the dataset using either a text query or an image query.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.SearchApiApi;


SearchApiApi apiInstance = new SearchApiApi();
SearchBody body = new SearchBody(); // SearchBody | Request to search the dataset using text or image query.
String authorization = "authorization_example"; // String | 
String accept = "application/json"; // String | 
String contentType = "application/json"; // String | 
try {
    InlineResponse2002 result = apiInstance.searchDataset(body, authorization, accept, contentType);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SearchApiApi#searchDataset");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**SearchBody**](SearchBody.md)| Request to search the dataset using text or image query. |
 **authorization** | **String**|  |
 **accept** | **String**|  | [default to application/json]
 **contentType** | **String**|  | [default to application/json]

### Return type

[**InlineResponse2002**](InlineResponse2002.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

