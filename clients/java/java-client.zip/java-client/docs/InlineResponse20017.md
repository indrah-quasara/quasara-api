# InlineResponse20017

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_id** | **String** | The unique identifier of the session. |  [optional]
**userId** | **String** | The ID of the user who owns this session. |  [optional]
**context** | **List&lt;Object&gt;** | List of context items providing reference information for the conversation. |  [optional]
**tagIds** | **List&lt;String&gt;** | List of tag IDs associated with this session for filtering knowledge base content. |  [optional]
**history** | **List&lt;Object&gt;** | The conversation history between user and assistant. |  [optional]
**timestamp** | **String** | The timestamp when the session was created or last updated. |  [optional]
