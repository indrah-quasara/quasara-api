# swagger_client.EMBEDAPIApi

All URIs are relative to */*

Method | HTTP request | Description
------------- | ------------- | -------------
[**define_dataset**](EMBEDAPIApi.md#define_dataset) | **POST** /define-dataset | Define a New Dataset
[**download_embeddings**](EMBEDAPIApi.md#download_embeddings) | **POST** /download-embeddings | Download Embeddings for a Tag
[**extract_embeddings**](EMBEDAPIApi.md#extract_embeddings) | **POST** /extract-embeddings | Extract Embeddings from Dataset
[**extract_entities**](EMBEDAPIApi.md#extract_entities) | **POST** /entity_extraction | Extract Entities from Dataset
[**get_models**](EMBEDAPIApi.md#get_models) | **GET** /llm_models | Get Available LLM Models
[**get_session**](EMBEDAPIApi.md#get_session) | **GET** /session/{session_id} | Get Session Data
[**get_session_ids**](EMBEDAPIApi.md#get_session_ids) | **GET** /session_ids | Get User&#x27;s Session IDs
[**retrieve_entity_extraction_data**](EMBEDAPIApi.md#retrieve_entity_extraction_data) | **POST** /retrieve-entity-extraction-data/ | Retrieve Entity Extraction Data
[**send_message**](EMBEDAPIApi.md#send_message) | **POST** /message | Send Message for RAG Processing
[**upload_dataset**](EMBEDAPIApi.md#upload_dataset) | **POST** /upload-dataset | Upload a Dataset ZIP File

# **define_dataset**
> InlineResponse200 define_dataset(body, authorization, accept, content_type)

Define a New Dataset

This endpoint allows users to define a new dataset.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.EMBEDAPIApi()
body = swagger_client.DefinedatasetBody() # DefinedatasetBody | Define a new dataset by providing necessary details.
authorization = 'authorization_example' # str | 
accept = 'application/json' # str |  (default to application/json)
content_type = 'application/json' # str |  (default to application/json)

try:
    # Define a New Dataset
    api_response = api_instance.define_dataset(body, authorization, accept, content_type)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling EMBEDAPIApi->define_dataset: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**DefinedatasetBody**](DefinedatasetBody.md)| Define a new dataset by providing necessary details. | 
 **authorization** | **str**|  | 
 **accept** | **str**|  | [default to application/json]
 **content_type** | **str**|  | [default to application/json]

### Return type

[**InlineResponse200**](InlineResponse200.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **download_embeddings**
> InlineResponse201 download_embeddings(body, authorization, accept, content_type)

Download Embeddings for a Tag

This endpoint allows users to download embeddings associated with a specific tag.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.EMBEDAPIApi()
body = swagger_client.DownloadembeddingsBody() # DownloadembeddingsBody | Request to download embeddings for a specific tag.
authorization = 'authorization_example' # str | 
accept = 'application/json' # str |  (default to application/json)
content_type = 'application/json' # str |  (default to application/json)

try:
    # Download Embeddings for a Tag
    api_response = api_instance.download_embeddings(body, authorization, accept, content_type)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling EMBEDAPIApi->download_embeddings: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**DownloadembeddingsBody**](DownloadembeddingsBody.md)| Request to download embeddings for a specific tag. | 
 **authorization** | **str**|  | 
 **accept** | **str**|  | [default to application/json]
 **content_type** | **str**|  | [default to application/json]

### Return type

[**InlineResponse201**](InlineResponse201.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **extract_embeddings**
> InlineResponse201 extract_embeddings(body, authorization, accept, content_type)

Extract Embeddings from Dataset

This endpoint allows users to extract embeddings from a specified dataset using a given model and configuration options.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.EMBEDAPIApi()
body = swagger_client.ExtractembeddingsBody() # ExtractembeddingsBody | Request to extract embeddings from the dataset.
authorization = 'authorization_example' # str | 
accept = 'application/json' # str |  (default to application/json)
content_type = 'application/json' # str |  (default to application/json)

try:
    # Extract Embeddings from Dataset
    api_response = api_instance.extract_embeddings(body, authorization, accept, content_type)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling EMBEDAPIApi->extract_embeddings: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**ExtractembeddingsBody**](ExtractembeddingsBody.md)| Request to extract embeddings from the dataset. | 
 **authorization** | **str**|  | 
 **accept** | **str**|  | [default to application/json]
 **content_type** | **str**|  | [default to application/json]

### Return type

[**InlineResponse201**](InlineResponse201.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **extract_entities**
> InlineResponse201 extract_entities(body, authorization, accept, content_type)

Extract Entities from Dataset

This endpoint allows users to extract entities from a specified dataset using a given model.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.EMBEDAPIApi()
body = swagger_client.EntityExtractionBody() # EntityExtractionBody | Request to extract entities from the dataset.
authorization = 'authorization_example' # str | 
accept = 'application/json' # str |  (default to application/json)
content_type = 'application/json' # str |  (default to application/json)

try:
    # Extract Entities from Dataset
    api_response = api_instance.extract_entities(body, authorization, accept, content_type)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling EMBEDAPIApi->extract_entities: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**EntityExtractionBody**](EntityExtractionBody.md)| Request to extract entities from the dataset. | 
 **authorization** | **str**|  | 
 **accept** | **str**|  | [default to application/json]
 **content_type** | **str**|  | [default to application/json]

### Return type

[**InlineResponse201**](InlineResponse201.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_models**
> InlineResponse20016 get_models(authorization, accept)

Get Available LLM Models

This endpoint returns a list of available language models that can be used for processing.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.EMBEDAPIApi()
authorization = 'authorization_example' # str | 
accept = 'application/json' # str |  (default to application/json)

try:
    # Get Available LLM Models
    api_response = api_instance.get_models(authorization, accept)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling EMBEDAPIApi->get_models: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **str**|  | 
 **accept** | **str**|  | [default to application/json]

### Return type

[**InlineResponse20016**](InlineResponse20016.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_session**
> InlineResponse20017 get_session(session_id, authorization, accept)

Get Session Data

This endpoint retrieves session data for a specific session ID, with any MongoDB ObjectIds converted to strings.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.EMBEDAPIApi()
session_id = 'session_id_example' # str | 
authorization = 'authorization_example' # str | 
accept = 'application/json' # str |  (default to application/json)

try:
    # Get Session Data
    api_response = api_instance.get_session(session_id, authorization, accept)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling EMBEDAPIApi->get_session: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **session_id** | **str**|  | 
 **authorization** | **str**|  | 
 **accept** | **str**|  | [default to application/json]

### Return type

[**InlineResponse20017**](InlineResponse20017.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_session_ids**
> InlineResponse20018 get_session_ids(authorization, accept)

Get User's Session IDs

This endpoint retrieves all session IDs associated with the authenticated user.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.EMBEDAPIApi()
authorization = 'authorization_example' # str | 
accept = 'application/json' # str |  (default to application/json)

try:
    # Get User's Session IDs
    api_response = api_instance.get_session_ids(authorization, accept)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling EMBEDAPIApi->get_session_ids: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **str**|  | 
 **accept** | **str**|  | [default to application/json]

### Return type

[**InlineResponse20018**](InlineResponse20018.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **retrieve_entity_extraction_data**
> InlineResponse20014 retrieve_entity_extraction_data(body, authorization, accept, content_type)

Retrieve Entity Extraction Data

This endpoint allows users to retrieve previously extracted entity data with pagination.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.EMBEDAPIApi()
body = swagger_client.RetrieveentityextractiondataBody() # RetrieveentityextractiondataBody | Request to retrieve entity extraction data.
authorization = 'authorization_example' # str | 
accept = 'application/json' # str |  (default to application/json)
content_type = 'application/json' # str |  (default to application/json)

try:
    # Retrieve Entity Extraction Data
    api_response = api_instance.retrieve_entity_extraction_data(body, authorization, accept, content_type)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling EMBEDAPIApi->retrieve_entity_extraction_data: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**RetrieveentityextractiondataBody**](RetrieveentityextractiondataBody.md)| Request to retrieve entity extraction data. | 
 **authorization** | **str**|  | 
 **accept** | **str**|  | [default to application/json]
 **content_type** | **str**|  | [default to application/json]

### Return type

[**InlineResponse20014**](InlineResponse20014.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **send_message**
> InlineResponse20015 send_message(body, authorization, accept, content_type)

Send Message for RAG Processing

This endpoint allows users to send a message for processing using Retrieval Augmented Generation (RAG).

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.EMBEDAPIApi()
body = swagger_client.MessageBody() # MessageBody | Request to process a user message using RAG.
authorization = 'authorization_example' # str | 
accept = 'application/json' # str |  (default to application/json)
content_type = 'application/json' # str |  (default to application/json)

try:
    # Send Message for RAG Processing
    api_response = api_instance.send_message(body, authorization, accept, content_type)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling EMBEDAPIApi->send_message: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**MessageBody**](MessageBody.md)| Request to process a user message using RAG. | 
 **authorization** | **str**|  | 
 **accept** | **str**|  | [default to application/json]
 **content_type** | **str**|  | [default to application/json]

### Return type

[**InlineResponse20015**](InlineResponse20015.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **upload_dataset**
> InlineResponse2001 upload_dataset(dataset_zip_file, dataset_id, authorization, accept, content_type)

Upload a Dataset ZIP File

This endpoint allows users to upload a ZIP file containing a dataset to a specific dataset ID.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.EMBEDAPIApi()
dataset_zip_file = 'B' # str | 
dataset_id = 'dataset_id_example' # str | 
authorization = 'authorization_example' # str | 
accept = 'application/json' # str |  (default to application/json)
content_type = 'multipart/form-data' # str |  (default to multipart/form-data)

try:
    # Upload a Dataset ZIP File
    api_response = api_instance.upload_dataset(dataset_zip_file, dataset_id, authorization, accept, content_type)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling EMBEDAPIApi->upload_dataset: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **dataset_zip_file** | **str**|  | 
 **dataset_id** | **str**|  | 
 **authorization** | **str**|  | 
 **accept** | **str**|  | [default to application/json]
 **content_type** | **str**|  | [default to multipart/form-data]

### Return type

[**InlineResponse2001**](InlineResponse2001.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: multipart/form-data
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

