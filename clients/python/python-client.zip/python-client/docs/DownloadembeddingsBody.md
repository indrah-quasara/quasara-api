# DownloadembeddingsBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**tag_id** | **str** | The unique identifier for the tag you want to download. | [optional] 
**update_embeddings** | **bool** | (Optional) Flag to indicate if embeddings need to be re-downloaded after a tag update. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

