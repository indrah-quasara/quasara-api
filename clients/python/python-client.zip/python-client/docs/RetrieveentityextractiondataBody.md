# RetrieveentityextractiondataBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**job_id** | **str** | The ID of the job whose entity extraction data is being queried. | 
**page** | **int** | The page number for pagination (min: 1). | [optional] [default to 1]
**page_size** | **int** | The number of items per page (min: 1, max: 50). | [optional] [default to 10]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

