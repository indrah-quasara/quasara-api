# EntityExtractionBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**dataset_id** | **str** | The unique identifier for the dataset. | 
**document_domain** | **str** | The domain of documents to process. Must be one of the supported domains. | 
**model_name** | **str** | The name of the model to be used for processing the dataset. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

