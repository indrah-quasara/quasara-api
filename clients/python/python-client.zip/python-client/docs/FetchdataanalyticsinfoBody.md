# FetchdataanalyticsinfoBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**tag_id** | **str** | The unique identifier for the tag. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

