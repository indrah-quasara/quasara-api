# FetchdataanalyticsresultsBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**data_analytics_id** | **str** | The unique identifier for the data analytics. This id is unique for a tag_id and corresponding data analytics configurations. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

