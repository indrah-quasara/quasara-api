# DetectobjectsBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**model_name** | **str** | The name of the model to use for embedding extraction. | [optional] 
**labels** | **list[str]** | List of labels to detect. | [optional] 
**dataset_id** | **str** | The ID of the dataset to extract embeddings from. | [optional] 
**batch_size** | **int** | Batch size for processing images. | [optional] 
**log_to_mail** | **bool** | Whether to log errors to email. | [optional] 
**search_results_id** | **str** | Optional ID of the search results. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

