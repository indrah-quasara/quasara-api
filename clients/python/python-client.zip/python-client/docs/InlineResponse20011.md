# InlineResponse20011

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**job_id** | **str** | The unique identifier of the job. | [optional] 
**dataset_id** | **str** | The unique identifier of the dataset associated with the job. | [optional] 
**status** | **str** | The current status of the job. | [optional] 
**message** | **str** | A message associated with the job status. | [optional] 
**time** | **datetime** | The timestamp of the job creation or last update. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

