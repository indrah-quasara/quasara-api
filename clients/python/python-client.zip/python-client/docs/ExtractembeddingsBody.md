# ExtractembeddingsBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**dataset_id** | **str** | The unique identifier for the dataset. | [optional] 
**model_name** | **str** | (Optional) The name of the model to use for processing the dataset. Format: model_name:version. | [optional] 
**split_method** | **str** | (Optional) The method for splitting the dataset. If not provided, the default method will be used. | [optional] 
**process_splits** | **bool** | (Optional) Flag to indicate if splits should be processed. Defaults to true. | [optional] 
**process_images** | **bool** | (Optional) Flag to indicate if images should be processed. Defaults to true. | [optional] 
**batch_size** | **int** | (Optional) The number of items to process in each batch. | [optional] 
**log_to_mail** | **bool** | (Optional) Flag to receive email notifications about the job status. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

