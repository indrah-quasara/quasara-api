# SearchBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**tag_ids** | **list[str]** | A list of tag IDs to filter the dataset. Only results matching these tags will be included in the search. | [optional] 
**text_query** | **str** | (Optional) A text query to search the dataset. Only one text query is supported for now. | [optional] 
**image_query** | **str** | (Optional) A base64 encoded image query to search the dataset. Only one image query is supported for now. | [optional] 
**search_in_small_objects** | **bool** | (Optional) Set this to true to search for small objects. Defaults to false if not specified. | [optional] 
**search_in_images** | **bool** | (Optional) Set this to true to search within images. At least one of search_in_images or search_in_small_objects must be true. | [optional] 
**limit** | **int** | (Optional) The maximum number of search results to return. If not provided, the default limit is 10. | [optional] 
**offset** | **int** | (Optional) The starting point for search results, useful for pagination. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

