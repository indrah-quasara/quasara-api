# swagger_client.JOBMANAGEMENTAUTHORISATIONApi

All URIs are relative to */*

Method | HTTP request | Description
------------- | ------------- | -------------
[**analyze_data**](JOBMANAGEMENTAUTHORISATIONApi.md#analyze_data) | **POST** /analyze-data | Analyze Data
[**check_job_status**](JOBMANAGEMENTAUTHORISATIONApi.md#check_job_status) | **POST** /job-status | Check Job Status
[**get_user_jobs**](JOBMANAGEMENTAUTHORISATIONApi.md#get_user_jobs) | **GET** /jobs | Fetch User&#x27;s Jobs
[**login**](JOBMANAGEMENTAUTHORISATIONApi.md#login) | **POST** /login | Login to get API Key
[**pause_job**](JOBMANAGEMENTAUTHORISATIONApi.md#pause_job) | **PUT** /pause-job | Pause a Running Job

# **analyze_data**
> InlineResponse2009 analyze_data(body)

Analyze Data

This endpoint allows users to initiate clustering, similarity, and outlier detection for a specified tag.  If the data analytics process has already been completed for the given tag, a message will be returned,  and users can use the `/fetch-data-analytics` endpoint to retrieve the results. Otherwise, the API creates  a job and returns a job ID. 

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.JOBMANAGEMENTAUTHORISATIONApi()
body = swagger_client.AnalyzedataBody() # AnalyzedataBody | 

try:
    # Analyze Data
    api_response = api_instance.analyze_data(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling JOBMANAGEMENTAUTHORISATIONApi->analyze_data: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**AnalyzedataBody**](AnalyzedataBody.md)|  | 

### Return type

[**InlineResponse2009**](InlineResponse2009.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **check_job_status**
> InlineResponse20010 check_job_status(body, authorization, accept, content_type)

Check Job Status

This endpoint allows users to check the current status of a specific job.  By providing the job ID, the API returns the job's status, including the processing stage and additional details. 

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.JOBMANAGEMENTAUTHORISATIONApi()
body = swagger_client.JobstatusBody() # JobstatusBody | 
authorization = 'authorization_example' # str | 
accept = 'application/json' # str |  (default to application/json)
content_type = 'application/json' # str |  (default to application/json)

try:
    # Check Job Status
    api_response = api_instance.check_job_status(body, authorization, accept, content_type)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling JOBMANAGEMENTAUTHORISATIONApi->check_job_status: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**JobstatusBody**](JobstatusBody.md)|  | 
 **authorization** | **str**|  | 
 **accept** | **str**|  | [default to application/json]
 **content_type** | **str**|  | [default to application/json]

### Return type

[**InlineResponse20010**](InlineResponse20010.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_user_jobs**
> list[InlineResponse20011] get_user_jobs(authorization, accept)

Fetch User's Jobs

This endpoint retrieves a list of jobs associated with the authenticated user.  For each job, details such as job ID, the dataset it is linked to, current status,  a message, and the timestamp of creation or last update are included. 

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.JOBMANAGEMENTAUTHORISATIONApi()
authorization = 'authorization_example' # str | 
accept = 'application/json' # str |  (default to application/json)

try:
    # Fetch User's Jobs
    api_response = api_instance.get_user_jobs(authorization, accept)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling JOBMANAGEMENTAUTHORISATIONApi->get_user_jobs: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **str**|  | 
 **accept** | **str**|  | [default to application/json]

### Return type

[**list[InlineResponse20011]**](InlineResponse20011.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **login**
> InlineResponse20013 login(body)

Login to get API Key

This endpoint allows users to obtain an API key by providing their email and password for authentication. 

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.JOBMANAGEMENTAUTHORISATIONApi()
body = swagger_client.LoginBody() # LoginBody | 

try:
    # Login to get API Key
    api_response = api_instance.login(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling JOBMANAGEMENTAUTHORISATIONApi->login: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**LoginBody**](LoginBody.md)|  | 

### Return type

[**InlineResponse20013**](InlineResponse20013.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **pause_job**
> InlineResponse20012 pause_job(body, authorization, accept, content_type)

Pause a Running Job

This endpoint allows users to pause a currently running job by updating its status to \"STOPPING_PAUSED\" or \"PAUSED\".  If the job is already completed, paused, or in a non-pausable state, the current status will be returned without making any changes. 

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.JOBMANAGEMENTAUTHORISATIONApi()
body = swagger_client.PausejobBody() # PausejobBody | 
authorization = 'authorization_example' # str | 
accept = 'application/json' # str |  (default to application/json)
content_type = 'application/json' # str |  (default to application/json)

try:
    # Pause a Running Job
    api_response = api_instance.pause_job(body, authorization, accept, content_type)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling JOBMANAGEMENTAUTHORISATIONApi->pause_job: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**PausejobBody**](PausejobBody.md)|  | 
 **authorization** | **str**|  | 
 **accept** | **str**|  | [default to application/json]
 **content_type** | **str**|  | [default to application/json]

### Return type

[**InlineResponse20012**](InlineResponse20012.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

