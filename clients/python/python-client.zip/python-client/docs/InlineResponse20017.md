# InlineResponse20017

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** | The unique identifier of the session. | [optional] 
**user_id** | **str** | The ID of the user who owns this session. | [optional] 
**context** | **list[object]** | List of context items providing reference information for the conversation. | [optional] 
**tag_ids** | **list[str]** | List of tag IDs associated with this session for filtering knowledge base content. | [optional] 
**history** | **list[object]** | The conversation history between user and assistant. | [optional] 
**timestamp** | **str** | The timestamp when the session was created or last updated. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

