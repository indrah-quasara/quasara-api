# MessageBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**message** | **str** | The user message to be processed. | 
**tag_ids** | **list[str]** | List of tag IDs to filter relevant documents. | 
**model_name** | **str** | The name of the language model to be used for processing. | 
**conversation_id** | **str** | Optional ID of an existing conversation to continue. If not provided, a new conversation will be started. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

