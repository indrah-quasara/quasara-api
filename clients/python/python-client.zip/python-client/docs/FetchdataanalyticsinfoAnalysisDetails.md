# FetchdataanalyticsinfoAnalysisDetails

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**total_clusters** | **str** |  | [optional] 
**total_outliers** | **int** |  | [optional] 
**algorithm_time_taken** | **float** |  | [optional] 
**mean_cluster_size** | **float** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

