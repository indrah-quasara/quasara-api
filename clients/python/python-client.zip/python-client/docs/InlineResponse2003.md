# InlineResponse2003

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**data_analytics_id** | **str** |  | [optional] 
**type** | **str** |  | [optional] 
**algorithm** | **str** |  | [optional] 
**is_completed** | **bool** |  | [optional] 
**dimension_size** | **int** |  | [optional] 
**dimensionality_reduction_algorithm** | **str** |  | [optional] 
**score_threshold** | **float** |  | [optional] 
**contamination** | **float** |  | [optional] 
**analysis_details** | [**list[FetchdataanalyticsinfoAnalysisDetails]**](FetchdataanalyticsinfoAnalysisDetails.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

