# AnalyzedataBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**tag_id** | **str** | The unique identifier for the tag. | [optional] 
**analytic_type** | **str** | Type of the data analytics (clustering, similarity, or outlier). | [optional] 
**algorithm** | **str** | The main algorithm to be used for the process. | [optional] 
**dimensionality_reduction_algorithm** | **str** | The algorithm to be used for dimensionality reduction. | [optional] 
**dimension_size** | **int** | The size of the dimension for dimensionality reduction. | [optional] 
**score_threshold** | **float** | Threshold for clustering and similarity score. | [optional] 
**contamination** | **float** | Contamination for the outlier detection algorithm. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

