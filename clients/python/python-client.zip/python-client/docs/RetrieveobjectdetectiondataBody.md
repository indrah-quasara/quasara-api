# RetrieveobjectdetectiondataBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**job_id** | **str** | The unique identifier for the job. This ID corresponds to a specific job or operation being processed. | [optional] 
**page** | **int** | The page number to retrieve for paginated results. | [optional] 
**page_size** | **int** | The number of items to include per page in the paginated results. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

