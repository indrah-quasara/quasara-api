# InlineResponse20010

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**job_id** | **str** | The ID of the job being checked. | [optional] 
**status** | **str** | The current status of the job. | [optional] 
**message** | **str** | A message providing additional details about the job&#x27;s current state. | [optional] 
**bucket_idx** | **int** | The index of the bucket currently being processed, if applicable. | [optional] 
**batch** | **int** | The index of the batch currently being processed, if applicable. | [optional] 
**percentage** | **object** |  | [optional] 
**avg_batch_time** | **float** | Average batch time. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

