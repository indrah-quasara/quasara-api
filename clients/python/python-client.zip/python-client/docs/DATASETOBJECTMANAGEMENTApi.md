# swagger_client.DATASETOBJECTMANAGEMENTApi

All URIs are relative to */*

Method | HTTP request | Description
------------- | ------------- | -------------
[**detect_objects**](DATASETOBJECTMANAGEMENTApi.md#detect_objects) | **POST** /detect-objects | Initiate Object Detection Job
[**get_tags**](DATASETOBJECTMANAGEMENTApi.md#get_tags) | **GET** /tags | Retrieve Tags
[**list_datasets**](DATASETOBJECTMANAGEMENTApi.md#list_datasets) | **GET** /datasets | Retrieve List of Datasets
[**list_models**](DATASETOBJECTMANAGEMENTApi.md#list_models) | **GET** /models | Retrieve List of Models
[**update_tags**](DATASETOBJECTMANAGEMENTApi.md#update_tags) | **POST** /update-tags | Update Tags for Dataset

# **detect_objects**
> InlineResponse201 detect_objects(body, authorization, accept, content_type)

Initiate Object Detection Job

This endpoint allows users to start a job for object detection. Users can specify either `dataset_id` or `search_result_id`.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.DATASETOBJECTMANAGEMENTApi()
body = swagger_client.DetectobjectsBody() # DetectobjectsBody | Request to initiate an object detection job.
authorization = 'authorization_example' # str | 
accept = 'application/json' # str |  (default to application/json)
content_type = 'application/json' # str |  (default to application/json)

try:
    # Initiate Object Detection Job
    api_response = api_instance.detect_objects(body, authorization, accept, content_type)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DATASETOBJECTMANAGEMENTApi->detect_objects: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**DetectobjectsBody**](DetectobjectsBody.md)| Request to initiate an object detection job. | 
 **authorization** | **str**|  | 
 **accept** | **str**|  | [default to application/json]
 **content_type** | **str**|  | [default to application/json]

### Return type

[**InlineResponse201**](InlineResponse201.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_tags**
> InlineResponse2006 get_tags(authorization, accept)

Retrieve Tags

This endpoint allows users to retrieve a list of tags along with their associated resources and model labels.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.DATASETOBJECTMANAGEMENTApi()
authorization = 'authorization_example' # str | 
accept = 'application/json' # str |  (default to application/json)

try:
    # Retrieve Tags
    api_response = api_instance.get_tags(authorization, accept)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DATASETOBJECTMANAGEMENTApi->get_tags: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **str**|  | 
 **accept** | **str**|  | [default to application/json]

### Return type

[**InlineResponse2006**](InlineResponse2006.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **list_datasets**
> InlineResponse2007 list_datasets(authorization, accept)

Retrieve List of Datasets

This endpoint allows users to retrieve a list of available datasets.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.DATASETOBJECTMANAGEMENTApi()
authorization = 'authorization_example' # str | 
accept = 'application/json' # str |  (default to application/json)

try:
    # Retrieve List of Datasets
    api_response = api_instance.list_datasets(authorization, accept)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DATASETOBJECTMANAGEMENTApi->list_datasets: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **str**|  | 
 **accept** | **str**|  | [default to application/json]

### Return type

[**InlineResponse2007**](InlineResponse2007.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **list_models**
> InlineResponse2008 list_models(authorization, accept)

Retrieve List of Models

This endpoint allows users to retrieve a list of available models.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.DATASETOBJECTMANAGEMENTApi()
authorization = 'authorization_example' # str | 
accept = 'application/json' # str |  (default to application/json)

try:
    # Retrieve List of Models
    api_response = api_instance.list_models(authorization, accept)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DATASETOBJECTMANAGEMENTApi->list_models: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **str**|  | 
 **accept** | **str**|  | [default to application/json]

### Return type

[**InlineResponse2008**](InlineResponse2008.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **update_tags**
> InlineResponse2011 update_tags(body, authorization, accept, content_type)

Update Tags for Dataset

This endpoint allows users to update the tags associated with a specific dataset.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.DATASETOBJECTMANAGEMENTApi()
body = swagger_client.UpdatetagsBody() # UpdatetagsBody | 
authorization = 'authorization_example' # str | 
accept = 'application/json' # str |  (default to application/json)
content_type = 'application/json' # str |  (default to application/json)

try:
    # Update Tags for Dataset
    api_response = api_instance.update_tags(body, authorization, accept, content_type)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DATASETOBJECTMANAGEMENTApi->update_tags: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**UpdatetagsBody**](UpdatetagsBody.md)|  | 
 **authorization** | **str**|  | 
 **accept** | **str**|  | [default to application/json]
 **content_type** | **str**|  | [default to application/json]

### Return type

[**InlineResponse2011**](InlineResponse2011.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

