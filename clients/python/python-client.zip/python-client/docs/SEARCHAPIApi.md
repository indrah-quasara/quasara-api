# swagger_client.SEARCHAPIApi

All URIs are relative to */*

Method | HTTP request | Description
------------- | ------------- | -------------
[**fetch_data_analytics_info**](SEARCHAPIApi.md#fetch_data_analytics_info) | **POST** /fetch-data-analytics-info | Fetch Data Analytics Information
[**fetch_data_analytics_results**](SEARCHAPIApi.md#fetch_data_analytics_results) | **POST** /fetch-data-analytics-results | Fetch Data Analytics Results
[**retrieve_object_detection_data**](SEARCHAPIApi.md#retrieve_object_detection_data) | **POST** /retrieve-object-detection-data | Retrieve Object Detection Data
[**search_dataset**](SEARCHAPIApi.md#search_dataset) | **POST** /search | Search the Dataset

# **fetch_data_analytics_info**
> list[InlineResponse2003] fetch_data_analytics_info(body, authorization, accept, content_type)

Fetch Data Analytics Information

This endpoint allows users to retrieve the data analytics information for a specified tag.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.SEARCHAPIApi()
body = swagger_client.FetchdataanalyticsinfoBody() # FetchdataanalyticsinfoBody | Request to fetch the data analytics information for the specified tag.
authorization = 'authorization_example' # str | 
accept = 'application/json' # str |  (default to application/json)
content_type = 'application/json' # str |  (default to application/json)

try:
    # Fetch Data Analytics Information
    api_response = api_instance.fetch_data_analytics_info(body, authorization, accept, content_type)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SEARCHAPIApi->fetch_data_analytics_info: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**FetchdataanalyticsinfoBody**](FetchdataanalyticsinfoBody.md)| Request to fetch the data analytics information for the specified tag. | 
 **authorization** | **str**|  | 
 **accept** | **str**|  | [default to application/json]
 **content_type** | **str**|  | [default to application/json]

### Return type

[**list[InlineResponse2003]**](InlineResponse2003.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **fetch_data_analytics_results**
> list[InlineResponse2004] fetch_data_analytics_results(body, authorization, accept, content_type)

Fetch Data Analytics Results

This endpoint allows users to fetch the results of the data analytics process.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.SEARCHAPIApi()
body = swagger_client.FetchdataanalyticsresultsBody() # FetchdataanalyticsresultsBody | Request to fetch the results for the specified data analytics.
authorization = 'authorization_example' # str | 
accept = 'application/json' # str |  (default to application/json)
content_type = 'application/json' # str |  (default to application/json)

try:
    # Fetch Data Analytics Results
    api_response = api_instance.fetch_data_analytics_results(body, authorization, accept, content_type)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SEARCHAPIApi->fetch_data_analytics_results: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**FetchdataanalyticsresultsBody**](FetchdataanalyticsresultsBody.md)| Request to fetch the results for the specified data analytics. | 
 **authorization** | **str**|  | 
 **accept** | **str**|  | [default to application/json]
 **content_type** | **str**|  | [default to application/json]

### Return type

[**list[InlineResponse2004]**](InlineResponse2004.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **retrieve_object_detection_data**
> InlineResponse2005 retrieve_object_detection_data(body, authorization, accept, content_type)

Retrieve Object Detection Data

This endpoint allows users to retrieve object detection data for a specific job.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.SEARCHAPIApi()
body = swagger_client.RetrieveobjectdetectiondataBody() # RetrieveobjectdetectiondataBody | Request to fetch object detection data for a specified job.
authorization = 'authorization_example' # str | 
accept = 'application/json' # str |  (default to application/json)
content_type = 'application/json' # str |  (default to application/json)

try:
    # Retrieve Object Detection Data
    api_response = api_instance.retrieve_object_detection_data(body, authorization, accept, content_type)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SEARCHAPIApi->retrieve_object_detection_data: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**RetrieveobjectdetectiondataBody**](RetrieveobjectdetectiondataBody.md)| Request to fetch object detection data for a specified job. | 
 **authorization** | **str**|  | 
 **accept** | **str**|  | [default to application/json]
 **content_type** | **str**|  | [default to application/json]

### Return type

[**InlineResponse2005**](InlineResponse2005.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **search_dataset**
> InlineResponse2002 search_dataset(body, authorization, accept, content_type)

Search the Dataset

This endpoint allows users to search the dataset using either a text query or an image query.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.SEARCHAPIApi()
body = swagger_client.SearchBody() # SearchBody | Request to search the dataset using text or image query.
authorization = 'authorization_example' # str | 
accept = 'application/json' # str |  (default to application/json)
content_type = 'application/json' # str |  (default to application/json)

try:
    # Search the Dataset
    api_response = api_instance.search_dataset(body, authorization, accept, content_type)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SEARCHAPIApi->search_dataset: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**SearchBody**](SearchBody.md)| Request to search the dataset using text or image query. | 
 **authorization** | **str**|  | 
 **accept** | **str**|  | [default to application/json]
 **content_type** | **str**|  | [default to application/json]

### Return type

[**InlineResponse2002**](InlineResponse2002.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

