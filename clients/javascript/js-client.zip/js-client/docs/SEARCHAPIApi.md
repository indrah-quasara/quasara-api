# QuasaraApi.SEARCHAPIApi

All URIs are relative to */*

Method | HTTP request | Description
------------- | ------------- | -------------
[**fetchDataAnalyticsInfo**](SEARCHAPIApi.md#fetchDataAnalyticsInfo) | **POST** /fetch-data-analytics-info | Fetch Data Analytics Information
[**fetchDataAnalyticsResults**](SEARCHAPIApi.md#fetchDataAnalyticsResults) | **POST** /fetch-data-analytics-results | Fetch Data Analytics Results
[**retrieveObjectDetectionData**](SEARCHAPIApi.md#retrieveObjectDetectionData) | **POST** /retrieve-object-detection-data | Retrieve Object Detection Data
[**searchDataset**](SEARCHAPIApi.md#searchDataset) | **POST** /search | Search the Dataset

<a name="fetchDataAnalyticsInfo"></a>
# **fetchDataAnalyticsInfo**
> [InlineResponse2003] fetchDataAnalyticsInfo(body, authorization, accept, contentType)

Fetch Data Analytics Information

This endpoint allows users to retrieve the data analytics information for a specified tag.

### Example
```javascript
import {QuasaraApi} from 'quasara_api';

let apiInstance = new QuasaraApi.SEARCHAPIApi();
let body = new QuasaraApi.FetchdataanalyticsinfoBody(); // FetchdataanalyticsinfoBody | Request to fetch the data analytics information for the specified tag.
let authorization = "authorization_example"; // String | 
let accept = "application/json"; // String | 
let contentType = "application/json"; // String | 

apiInstance.fetchDataAnalyticsInfo(body, authorization, accept, contentType, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**FetchdataanalyticsinfoBody**](FetchdataanalyticsinfoBody.md)| Request to fetch the data analytics information for the specified tag. | 
 **authorization** | **String**|  | 
 **accept** | **String**|  | [default to application/json]
 **contentType** | **String**|  | [default to application/json]

### Return type

[**[InlineResponse2003]**](InlineResponse2003.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="fetchDataAnalyticsResults"></a>
# **fetchDataAnalyticsResults**
> [InlineResponse2004] fetchDataAnalyticsResults(body, authorization, accept, contentType)

Fetch Data Analytics Results

This endpoint allows users to fetch the results of the data analytics process.

### Example
```javascript
import {QuasaraApi} from 'quasara_api';

let apiInstance = new QuasaraApi.SEARCHAPIApi();
let body = new QuasaraApi.FetchdataanalyticsresultsBody(); // FetchdataanalyticsresultsBody | Request to fetch the results for the specified data analytics.
let authorization = "authorization_example"; // String | 
let accept = "application/json"; // String | 
let contentType = "application/json"; // String | 

apiInstance.fetchDataAnalyticsResults(body, authorization, accept, contentType, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**FetchdataanalyticsresultsBody**](FetchdataanalyticsresultsBody.md)| Request to fetch the results for the specified data analytics. | 
 **authorization** | **String**|  | 
 **accept** | **String**|  | [default to application/json]
 **contentType** | **String**|  | [default to application/json]

### Return type

[**[InlineResponse2004]**](InlineResponse2004.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="retrieveObjectDetectionData"></a>
# **retrieveObjectDetectionData**
> InlineResponse2005 retrieveObjectDetectionData(body, authorization, accept, contentType)

Retrieve Object Detection Data

This endpoint allows users to retrieve object detection data for a specific job.

### Example
```javascript
import {QuasaraApi} from 'quasara_api';

let apiInstance = new QuasaraApi.SEARCHAPIApi();
let body = new QuasaraApi.RetrieveobjectdetectiondataBody(); // RetrieveobjectdetectiondataBody | Request to fetch object detection data for a specified job.
let authorization = "authorization_example"; // String | 
let accept = "application/json"; // String | 
let contentType = "application/json"; // String | 

apiInstance.retrieveObjectDetectionData(body, authorization, accept, contentType, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**RetrieveobjectdetectiondataBody**](RetrieveobjectdetectiondataBody.md)| Request to fetch object detection data for a specified job. | 
 **authorization** | **String**|  | 
 **accept** | **String**|  | [default to application/json]
 **contentType** | **String**|  | [default to application/json]

### Return type

[**InlineResponse2005**](InlineResponse2005.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="searchDataset"></a>
# **searchDataset**
> InlineResponse2002 searchDataset(body, authorization, accept, contentType)

Search the Dataset

This endpoint allows users to search the dataset using either a text query or an image query.

### Example
```javascript
import {QuasaraApi} from 'quasara_api';

let apiInstance = new QuasaraApi.SEARCHAPIApi();
let body = new QuasaraApi.SearchBody(); // SearchBody | Request to search the dataset using text or image query.
let authorization = "authorization_example"; // String | 
let accept = "application/json"; // String | 
let contentType = "application/json"; // String | 

apiInstance.searchDataset(body, authorization, accept, contentType, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**SearchBody**](SearchBody.md)| Request to search the dataset using text or image query. | 
 **authorization** | **String**|  | 
 **accept** | **String**|  | [default to application/json]
 **contentType** | **String**|  | [default to application/json]

### Return type

[**InlineResponse2002**](InlineResponse2002.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

