# QuasaraApi.InlineResponse4043

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**error** | **String** |  | [optional] 
