# QuasaraApi.InlineResponse40011

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**error** | **String** |  | [optional] 
