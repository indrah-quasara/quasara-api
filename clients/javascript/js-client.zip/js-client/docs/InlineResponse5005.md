# QuasaraApi.InlineResponse5005

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**error** | **String** | Description of the error that occurred due to an internal server issue. | [optional] 
