# QuasaraApi.UpdatetagsBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**datasetId** | **String** | The unique identifier for the dataset. | [optional] 
