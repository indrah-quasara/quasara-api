# QuasaraApi.JOBMANAGEMENTAUTHORISATIONApi

All URIs are relative to */*

Method | HTTP request | Description
------------- | ------------- | -------------
[**analyzeData**](JOBMANAGEMENTAUTHORISATIONApi.md#analyzeData) | **POST** /analyze-data | Analyze Data
[**checkJobStatus**](JOBMANAGEMENTAUTHORISATIONApi.md#checkJobStatus) | **POST** /job-status | Check Job Status
[**getUserJobs**](JOBMANAGEMENTAUTHORISATIONApi.md#getUserJobs) | **GET** /jobs | Fetch User&#x27;s Jobs
[**login**](JOBMANAGEMENTAUTHORISATIONApi.md#login) | **POST** /login | Login to get API Key
[**pauseJob**](JOBMANAGEMENTAUTHORISATIONApi.md#pauseJob) | **PUT** /pause-job | Pause a Running Job

<a name="analyzeData"></a>
# **analyzeData**
> InlineResponse2009 analyzeData(body)

Analyze Data

This endpoint allows users to initiate clustering, similarity, and outlier detection for a specified tag.  If the data analytics process has already been completed for the given tag, a message will be returned,  and users can use the &#x60;/fetch-data-analytics&#x60; endpoint to retrieve the results. Otherwise, the API creates  a job and returns a job ID. 

### Example
```javascript
import {QuasaraApi} from 'quasara_api';

let apiInstance = new QuasaraApi.JOBMANAGEMENTAUTHORISATIONApi();
let body = new QuasaraApi.AnalyzedataBody(); // AnalyzedataBody | 

apiInstance.analyzeData(body, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**AnalyzedataBody**](AnalyzedataBody.md)|  | 

### Return type

[**InlineResponse2009**](InlineResponse2009.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="checkJobStatus"></a>
# **checkJobStatus**
> InlineResponse20010 checkJobStatus(body, authorization, accept, contentType)

Check Job Status

This endpoint allows users to check the current status of a specific job.  By providing the job ID, the API returns the job&#x27;s status, including the processing stage and additional details. 

### Example
```javascript
import {QuasaraApi} from 'quasara_api';

let apiInstance = new QuasaraApi.JOBMANAGEMENTAUTHORISATIONApi();
let body = new QuasaraApi.JobstatusBody(); // JobstatusBody | 
let authorization = "authorization_example"; // String | 
let accept = "application/json"; // String | 
let contentType = "application/json"; // String | 

apiInstance.checkJobStatus(body, authorization, accept, contentType, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**JobstatusBody**](JobstatusBody.md)|  | 
 **authorization** | **String**|  | 
 **accept** | **String**|  | [default to application/json]
 **contentType** | **String**|  | [default to application/json]

### Return type

[**InlineResponse20010**](InlineResponse20010.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="getUserJobs"></a>
# **getUserJobs**
> [InlineResponse20011] getUserJobs(authorization, accept)

Fetch User&#x27;s Jobs

This endpoint retrieves a list of jobs associated with the authenticated user.  For each job, details such as job ID, the dataset it is linked to, current status,  a message, and the timestamp of creation or last update are included. 

### Example
```javascript
import {QuasaraApi} from 'quasara_api';

let apiInstance = new QuasaraApi.JOBMANAGEMENTAUTHORISATIONApi();
let authorization = "authorization_example"; // String | 
let accept = "application/json"; // String | 

apiInstance.getUserJobs(authorization, accept, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **String**|  | 
 **accept** | **String**|  | [default to application/json]

### Return type

[**[InlineResponse20011]**](InlineResponse20011.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="login"></a>
# **login**
> InlineResponse20013 login(body)

Login to get API Key

This endpoint allows users to obtain an API key by providing their email and password for authentication. 

### Example
```javascript
import {QuasaraApi} from 'quasara_api';

let apiInstance = new QuasaraApi.JOBMANAGEMENTAUTHORISATIONApi();
let body = new QuasaraApi.LoginBody(); // LoginBody | 

apiInstance.login(body, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**LoginBody**](LoginBody.md)|  | 

### Return type

[**InlineResponse20013**](InlineResponse20013.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="pauseJob"></a>
# **pauseJob**
> InlineResponse20012 pauseJob(body, authorization, accept, contentType)

Pause a Running Job

This endpoint allows users to pause a currently running job by updating its status to \&quot;STOPPING_PAUSED\&quot; or \&quot;PAUSED\&quot;.  If the job is already completed, paused, or in a non-pausable state, the current status will be returned without making any changes. 

### Example
```javascript
import {QuasaraApi} from 'quasara_api';

let apiInstance = new QuasaraApi.JOBMANAGEMENTAUTHORISATIONApi();
let body = new QuasaraApi.PausejobBody(); // PausejobBody | 
let authorization = "authorization_example"; // String | 
let accept = "application/json"; // String | 
let contentType = "application/json"; // String | 

apiInstance.pauseJob(body, authorization, accept, contentType, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**PausejobBody**](PausejobBody.md)|  | 
 **authorization** | **String**|  | 
 **accept** | **String**|  | [default to application/json]
 **contentType** | **String**|  | [default to application/json]

### Return type

[**InlineResponse20012**](InlineResponse20012.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

