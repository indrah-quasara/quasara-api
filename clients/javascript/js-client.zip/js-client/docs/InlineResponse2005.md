# QuasaraApi.InlineResponse2005

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**currentPage** | **Number** |  | [optional] 
**pageSize** | **Number** |  | [optional] 
**totalCount** | **Number** |  | [optional] 
**totalPages** | **Number** |  | [optional] 
**results** | **[Object]** |  | [optional] 
