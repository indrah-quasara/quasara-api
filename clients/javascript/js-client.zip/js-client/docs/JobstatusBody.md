# QuasaraApi.JobstatusBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**jobId** | **String** | The unique identifier for the job you want to check. | [optional] 
