# QuasaraApi.InlineResponse2002

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**searchResultsId** | **String** |  | [optional] 
**results** | **[Object]** |  | [optional] 
