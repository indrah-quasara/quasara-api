# QuasaraApi.InlineResponse2006

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**results** | **[Object]** |  | [optional] 
