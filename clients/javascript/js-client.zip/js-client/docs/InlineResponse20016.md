# QuasaraApi.InlineResponse20016

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**models** | **[String]** | List of available model names | [optional] 
