# QuasaraApi.DefinedatasetBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**datasetDisplayName** | **String** | The display name of the dataset. | [optional] 
