# QuasaraApi.AnalyzedataBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**tagId** | **String** | The unique identifier for the tag. | [optional] 
**analyticType** | **String** | Type of the data analytics (clustering, similarity, or outlier). | [optional] 
**algorithm** | **String** | The main algorithm to be used for the process. | [optional] 
**dimensionalityReductionAlgorithm** | **String** | The algorithm to be used for dimensionality reduction. | [optional] 
**dimensionSize** | **Number** | The size of the dimension for dimensionality reduction. | [optional] 
**scoreThreshold** | **Number** | Threshold for clustering and similarity score. | [optional] 
**contamination** | **Number** | Contamination for the outlier detection algorithm. | [optional] 
