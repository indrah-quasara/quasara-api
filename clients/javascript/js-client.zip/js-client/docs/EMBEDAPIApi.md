# QuasaraApi.EMBEDAPIApi

All URIs are relative to */*

Method | HTTP request | Description
------------- | ------------- | -------------
[**defineDataset**](EMBEDAPIApi.md#defineDataset) | **POST** /define-dataset | Define a New Dataset
[**downloadEmbeddings**](EMBEDAPIApi.md#downloadEmbeddings) | **POST** /download-embeddings | Download Embeddings for a Tag
[**extractEmbeddings**](EMBEDAPIApi.md#extractEmbeddings) | **POST** /extract-embeddings | Extract Embeddings from Dataset
[**extractEntities**](EMBEDAPIApi.md#extractEntities) | **POST** /entity_extraction | Extract Entities from Dataset
[**getModels**](EMBEDAPIApi.md#getModels) | **GET** /llm_models | Get Available LLM Models
[**getSession**](EMBEDAPIApi.md#getSession) | **GET** /session/{session_id} | Get Session Data
[**getSessionIds**](EMBEDAPIApi.md#getSessionIds) | **GET** /session_ids | Get User&#x27;s Session IDs
[**retrieveEntityExtractionData**](EMBEDAPIApi.md#retrieveEntityExtractionData) | **POST** /retrieve-entity-extraction-data/ | Retrieve Entity Extraction Data
[**sendMessage**](EMBEDAPIApi.md#sendMessage) | **POST** /message | Send Message for RAG Processing
[**uploadDataset**](EMBEDAPIApi.md#uploadDataset) | **POST** /upload-dataset | Upload a Dataset ZIP File

<a name="defineDataset"></a>
# **defineDataset**
> InlineResponse200 defineDataset(body, authorization, accept, contentType)

Define a New Dataset

This endpoint allows users to define a new dataset.

### Example
```javascript
import {QuasaraApi} from 'quasara_api';

let apiInstance = new QuasaraApi.EMBEDAPIApi();
let body = new QuasaraApi.DefinedatasetBody(); // DefinedatasetBody | Define a new dataset by providing necessary details.
let authorization = "authorization_example"; // String | 
let accept = "application/json"; // String | 
let contentType = "application/json"; // String | 

apiInstance.defineDataset(body, authorization, accept, contentType, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**DefinedatasetBody**](DefinedatasetBody.md)| Define a new dataset by providing necessary details. | 
 **authorization** | **String**|  | 
 **accept** | **String**|  | [default to application/json]
 **contentType** | **String**|  | [default to application/json]

### Return type

[**InlineResponse200**](InlineResponse200.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="downloadEmbeddings"></a>
# **downloadEmbeddings**
> InlineResponse201 downloadEmbeddings(body, authorization, accept, contentType)

Download Embeddings for a Tag

This endpoint allows users to download embeddings associated with a specific tag.

### Example
```javascript
import {QuasaraApi} from 'quasara_api';

let apiInstance = new QuasaraApi.EMBEDAPIApi();
let body = new QuasaraApi.DownloadembeddingsBody(); // DownloadembeddingsBody | Request to download embeddings for a specific tag.
let authorization = "authorization_example"; // String | 
let accept = "application/json"; // String | 
let contentType = "application/json"; // String | 

apiInstance.downloadEmbeddings(body, authorization, accept, contentType, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**DownloadembeddingsBody**](DownloadembeddingsBody.md)| Request to download embeddings for a specific tag. | 
 **authorization** | **String**|  | 
 **accept** | **String**|  | [default to application/json]
 **contentType** | **String**|  | [default to application/json]

### Return type

[**InlineResponse201**](InlineResponse201.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="extractEmbeddings"></a>
# **extractEmbeddings**
> InlineResponse201 extractEmbeddings(body, authorization, accept, contentType)

Extract Embeddings from Dataset

This endpoint allows users to extract embeddings from a specified dataset using a given model and configuration options.

### Example
```javascript
import {QuasaraApi} from 'quasara_api';

let apiInstance = new QuasaraApi.EMBEDAPIApi();
let body = new QuasaraApi.ExtractembeddingsBody(); // ExtractembeddingsBody | Request to extract embeddings from the dataset.
let authorization = "authorization_example"; // String | 
let accept = "application/json"; // String | 
let contentType = "application/json"; // String | 

apiInstance.extractEmbeddings(body, authorization, accept, contentType, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**ExtractembeddingsBody**](ExtractembeddingsBody.md)| Request to extract embeddings from the dataset. | 
 **authorization** | **String**|  | 
 **accept** | **String**|  | [default to application/json]
 **contentType** | **String**|  | [default to application/json]

### Return type

[**InlineResponse201**](InlineResponse201.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="extractEntities"></a>
# **extractEntities**
> InlineResponse201 extractEntities(body, authorization, accept, contentType)

Extract Entities from Dataset

This endpoint allows users to extract entities from a specified dataset using a given model.

### Example
```javascript
import {QuasaraApi} from 'quasara_api';

let apiInstance = new QuasaraApi.EMBEDAPIApi();
let body = new QuasaraApi.EntityExtractionBody(); // EntityExtractionBody | Request to extract entities from the dataset.
let authorization = "authorization_example"; // String | 
let accept = "application/json"; // String | 
let contentType = "application/json"; // String | 

apiInstance.extractEntities(body, authorization, accept, contentType, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**EntityExtractionBody**](EntityExtractionBody.md)| Request to extract entities from the dataset. | 
 **authorization** | **String**|  | 
 **accept** | **String**|  | [default to application/json]
 **contentType** | **String**|  | [default to application/json]

### Return type

[**InlineResponse201**](InlineResponse201.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="getModels"></a>
# **getModels**
> InlineResponse20016 getModels(authorization, accept)

Get Available LLM Models

This endpoint returns a list of available language models that can be used for processing.

### Example
```javascript
import {QuasaraApi} from 'quasara_api';

let apiInstance = new QuasaraApi.EMBEDAPIApi();
let authorization = "authorization_example"; // String | 
let accept = "application/json"; // String | 

apiInstance.getModels(authorization, accept, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **String**|  | 
 **accept** | **String**|  | [default to application/json]

### Return type

[**InlineResponse20016**](InlineResponse20016.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="getSession"></a>
# **getSession**
> InlineResponse20017 getSession(sessionId, authorization, accept)

Get Session Data

This endpoint retrieves session data for a specific session ID, with any MongoDB ObjectIds converted to strings.

### Example
```javascript
import {QuasaraApi} from 'quasara_api';

let apiInstance = new QuasaraApi.EMBEDAPIApi();
let sessionId = "sessionId_example"; // String | 
let authorization = "authorization_example"; // String | 
let accept = "application/json"; // String | 

apiInstance.getSession(sessionId, authorization, accept, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sessionId** | **String**|  | 
 **authorization** | **String**|  | 
 **accept** | **String**|  | [default to application/json]

### Return type

[**InlineResponse20017**](InlineResponse20017.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="getSessionIds"></a>
# **getSessionIds**
> InlineResponse20018 getSessionIds(authorization, accept)

Get User&#x27;s Session IDs

This endpoint retrieves all session IDs associated with the authenticated user.

### Example
```javascript
import {QuasaraApi} from 'quasara_api';

let apiInstance = new QuasaraApi.EMBEDAPIApi();
let authorization = "authorization_example"; // String | 
let accept = "application/json"; // String | 

apiInstance.getSessionIds(authorization, accept, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **String**|  | 
 **accept** | **String**|  | [default to application/json]

### Return type

[**InlineResponse20018**](InlineResponse20018.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="retrieveEntityExtractionData"></a>
# **retrieveEntityExtractionData**
> InlineResponse20014 retrieveEntityExtractionData(body, authorization, accept, contentType)

Retrieve Entity Extraction Data

This endpoint allows users to retrieve previously extracted entity data with pagination.

### Example
```javascript
import {QuasaraApi} from 'quasara_api';

let apiInstance = new QuasaraApi.EMBEDAPIApi();
let body = new QuasaraApi.RetrieveentityextractiondataBody(); // RetrieveentityextractiondataBody | Request to retrieve entity extraction data.
let authorization = "authorization_example"; // String | 
let accept = "application/json"; // String | 
let contentType = "application/json"; // String | 

apiInstance.retrieveEntityExtractionData(body, authorization, accept, contentType, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**RetrieveentityextractiondataBody**](RetrieveentityextractiondataBody.md)| Request to retrieve entity extraction data. | 
 **authorization** | **String**|  | 
 **accept** | **String**|  | [default to application/json]
 **contentType** | **String**|  | [default to application/json]

### Return type

[**InlineResponse20014**](InlineResponse20014.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="sendMessage"></a>
# **sendMessage**
> InlineResponse20015 sendMessage(body, authorization, accept, contentType)

Send Message for RAG Processing

This endpoint allows users to send a message for processing using Retrieval Augmented Generation (RAG).

### Example
```javascript
import {QuasaraApi} from 'quasara_api';

let apiInstance = new QuasaraApi.EMBEDAPIApi();
let body = new QuasaraApi.MessageBody(); // MessageBody | Request to process a user message using RAG.
let authorization = "authorization_example"; // String | 
let accept = "application/json"; // String | 
let contentType = "application/json"; // String | 

apiInstance.sendMessage(body, authorization, accept, contentType, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**MessageBody**](MessageBody.md)| Request to process a user message using RAG. | 
 **authorization** | **String**|  | 
 **accept** | **String**|  | [default to application/json]
 **contentType** | **String**|  | [default to application/json]

### Return type

[**InlineResponse20015**](InlineResponse20015.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="uploadDataset"></a>
# **uploadDataset**
> InlineResponse2001 uploadDataset(datasetZipFile, datasetId, authorization, accept, contentType)

Upload a Dataset ZIP File

This endpoint allows users to upload a ZIP file containing a dataset to a specific dataset ID.

### Example
```javascript
import {QuasaraApi} from 'quasara_api';

let apiInstance = new QuasaraApi.EMBEDAPIApi();
let datasetZipFile = "QmFzZTY0IGV4YW1wbGU="; // Blob | 
let datasetId = "datasetId_example"; // String | 
let authorization = "authorization_example"; // String | 
let accept = "application/json"; // String | 
let contentType = "multipart/form-data"; // String | 

apiInstance.uploadDataset(datasetZipFile, datasetId, authorization, accept, contentType, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **datasetZipFile** | **Blob**|  | 
 **datasetId** | **String**|  | 
 **authorization** | **String**|  | 
 **accept** | **String**|  | [default to application/json]
 **contentType** | **String**|  | [default to multipart/form-data]

### Return type

[**InlineResponse2001**](InlineResponse2001.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: multipart/form-data
 - **Accept**: application/json

