# QuasaraApi.InlineResponse2008

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**results** | **[Object]** |  | [optional] 
