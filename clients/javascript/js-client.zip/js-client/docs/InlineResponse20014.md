# QuasaraApi.InlineResponse20014

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**currentPage** | **Number** |  | [optional] 
**pageSize** | **Number** |  | [optional] 
**totalCount** | **Number** |  | [optional] 
**totalPages** | **Number** |  | [optional] 
**results** | **[Object]** | Array of extracted entity data objects | [optional] 
