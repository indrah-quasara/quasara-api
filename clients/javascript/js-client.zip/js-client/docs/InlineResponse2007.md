# QuasaraApi.InlineResponse2007

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**results** | **[Object]** |  | [optional] 
