# QuasaraApi.InlineResponse20017

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** | The unique identifier of the session. | [optional] 
**userId** | **String** | The ID of the user who owns this session. | [optional] 
**context** | **[Object]** | List of context items providing reference information for the conversation. | [optional] 
**tagIds** | **[String]** | List of tag IDs associated with this session for filtering knowledge base content. | [optional] 
**history** | **[Object]** | The conversation history between user and assistant. | [optional] 
**timestamp** | **String** | The timestamp when the session was created or last updated. | [optional] 
