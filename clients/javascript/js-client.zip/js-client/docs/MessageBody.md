# QuasaraApi.MessageBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**message** | **String** | The user message to be processed. | 
**tagIds** | **[String]** | List of tag IDs to filter relevant documents. | 
**modelName** | **String** | The name of the language model to be used for processing. | 
**conversationId** | **String** | Optional ID of an existing conversation to continue. If not provided, a new conversation will be started. | [optional] 
