# QuasaraApi.UploaddatasetBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**datasetZipFile** | **Blob** | The ZIP file containing the dataset. | [optional] 
**datasetId** | **String** | The unique identifier for the dataset being updated. | [optional] 
