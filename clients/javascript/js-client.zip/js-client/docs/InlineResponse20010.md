# QuasaraApi.InlineResponse20010

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**jobId** | **String** | The ID of the job being checked. | [optional] 
**status** | **String** | The current status of the job. | [optional] 
**message** | **String** | A message providing additional details about the job&#x27;s current state. | [optional] 
**bucketIdx** | **Number** | The index of the bucket currently being processed, if applicable. | [optional] 
**batch** | **Number** | The index of the batch currently being processed, if applicable. | [optional] 
**percentage** | **Object** |  | [optional] 
**avgBatchTime** | **Number** | Average batch time. | [optional] 
