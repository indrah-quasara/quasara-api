# QuasaraApi.InlineResponse20018

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sessions** | **[String]** | List of session IDs belonging to the user | [optional] 
