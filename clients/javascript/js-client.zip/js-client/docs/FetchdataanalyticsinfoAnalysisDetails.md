# QuasaraApi.FetchdataanalyticsinfoAnalysisDetails

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**totalClusters** | **String** |  | [optional] 
**totalOutliers** | **Number** |  | [optional] 
**algorithmTimeTaken** | **Number** |  | [optional] 
**meanClusterSize** | **Number** |  | [optional] 
