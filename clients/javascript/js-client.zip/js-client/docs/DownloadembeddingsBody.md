# QuasaraApi.DownloadembeddingsBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**tagId** | **String** | The unique identifier for the tag you want to download. | [optional] 
**updateEmbeddings** | **Boolean** | (Optional) Flag to indicate if embeddings need to be re-downloaded after a tag update. | [optional] 
