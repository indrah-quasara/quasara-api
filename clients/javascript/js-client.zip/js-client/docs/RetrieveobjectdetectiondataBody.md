# QuasaraApi.RetrieveobjectdetectiondataBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**jobId** | **String** | The unique identifier for the job. This ID corresponds to a specific job or operation being processed. | [optional] 
**page** | **Number** | The page number to retrieve for paginated results. | [optional] 
**pageSize** | **Number** | The number of items to include per page in the paginated results. | [optional] 
