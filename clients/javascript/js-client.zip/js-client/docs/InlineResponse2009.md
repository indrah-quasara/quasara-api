# QuasaraApi.InlineResponse2009

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**dataAnalyticId** | **String** | The unique identifier for the data analytics process. | [optional] 
**message** | **String** | Message indicating the process is already done. | [optional] 
