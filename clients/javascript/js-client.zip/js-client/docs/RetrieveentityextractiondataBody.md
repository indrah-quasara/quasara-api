# QuasaraApi.RetrieveentityextractiondataBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**jobId** | **String** | The ID of the job whose entity extraction data is being queried. | 
**page** | **Number** | The page number for pagination (min: 1). | [optional] [default to 1]
**pageSize** | **Number** | The number of items per page (min: 1, max: 50). | [optional] [default to 10]
