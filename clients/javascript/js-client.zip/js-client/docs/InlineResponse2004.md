# QuasaraApi.InlineResponse2004

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**s3Path** | **String** |  | [optional] 
**clusterLabel** | **Number** |  | [optional] 
**visualizationVector** | **[Number]** |  | [optional] 
