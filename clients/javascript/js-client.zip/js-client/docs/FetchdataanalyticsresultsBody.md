# QuasaraApi.FetchdataanalyticsresultsBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**dataAnalyticsId** | **String** | The unique identifier for the data analytics. This id is unique for a tag_id and corresponding data analytics configurations. | [optional] 
