# QuasaraApi.InlineResponse4007

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**error** | **String** | Description of the error. | [optional] 
