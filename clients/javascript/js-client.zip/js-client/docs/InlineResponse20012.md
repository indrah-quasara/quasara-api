# QuasaraApi.InlineResponse20012

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**jobId** | **String** | The ID of the job being paused. | [optional] 
**status** | **String** | The updated or current status of the job. | [optional] 
**message** | **String** | A message describing the current state of the job. | [optional] 
