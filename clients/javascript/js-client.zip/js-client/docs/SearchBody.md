# QuasaraApi.SearchBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**tagIds** | **[String]** | A list of tag IDs to filter the dataset. Only results matching these tags will be included in the search. | [optional] 
**textQuery** | **String** | (Optional) A text query to search the dataset. Only one text query is supported for now. | [optional] 
**imageQuery** | **String** | (Optional) A base64 encoded image query to search the dataset. Only one image query is supported for now. | [optional] 
**searchInSmallObjects** | **Boolean** | (Optional) Set this to true to search for small objects. Defaults to false if not specified. | [optional] 
**searchInImages** | **Boolean** | (Optional) Set this to true to search within images. At least one of search_in_images or search_in_small_objects must be true. | [optional] 
**limit** | **Number** | (Optional) The maximum number of search results to return. If not provided, the default limit is 10. | [optional] 
**offset** | **Number** | (Optional) The starting point for search results, useful for pagination. | [optional] 
