# QuasaraApi.InlineResponse5004

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**error** | **String** | Description of the error due to an internal server issue. | [optional] 
