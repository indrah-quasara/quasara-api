# QuasaraApi.DATASETOBJECTMANAGEMENTApi

All URIs are relative to */*

Method | HTTP request | Description
------------- | ------------- | -------------
[**detectObjects**](DATASETOBJECTMANAGEMENTApi.md#detectObjects) | **POST** /detect-objects | Initiate Object Detection Job
[**getTags**](DATASETOBJECTMANAGEMENTApi.md#getTags) | **GET** /tags | Retrieve Tags
[**listDatasets**](DATASETOBJECTMANAGEMENTApi.md#listDatasets) | **GET** /datasets | Retrieve List of Datasets
[**listModels**](DATASETOBJECTMANAGEMENTApi.md#listModels) | **GET** /models | Retrieve List of Models
[**updateTags**](DATASETOBJECTMANAGEMENTApi.md#updateTags) | **POST** /update-tags | Update Tags for Dataset

<a name="detectObjects"></a>
# **detectObjects**
> InlineResponse201 detectObjects(body, authorization, accept, contentType)

Initiate Object Detection Job

This endpoint allows users to start a job for object detection. Users can specify either &#x60;dataset_id&#x60; or &#x60;search_result_id&#x60;.

### Example
```javascript
import {QuasaraApi} from 'quasara_api';

let apiInstance = new QuasaraApi.DATASETOBJECTMANAGEMENTApi();
let body = new QuasaraApi.DetectobjectsBody(); // DetectobjectsBody | Request to initiate an object detection job.
let authorization = "authorization_example"; // String | 
let accept = "application/json"; // String | 
let contentType = "application/json"; // String | 

apiInstance.detectObjects(body, authorization, accept, contentType, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**DetectobjectsBody**](DetectobjectsBody.md)| Request to initiate an object detection job. | 
 **authorization** | **String**|  | 
 **accept** | **String**|  | [default to application/json]
 **contentType** | **String**|  | [default to application/json]

### Return type

[**InlineResponse201**](InlineResponse201.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="getTags"></a>
# **getTags**
> InlineResponse2006 getTags(authorization, accept)

Retrieve Tags

This endpoint allows users to retrieve a list of tags along with their associated resources and model labels.

### Example
```javascript
import {QuasaraApi} from 'quasara_api';

let apiInstance = new QuasaraApi.DATASETOBJECTMANAGEMENTApi();
let authorization = "authorization_example"; // String | 
let accept = "application/json"; // String | 

apiInstance.getTags(authorization, accept, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **String**|  | 
 **accept** | **String**|  | [default to application/json]

### Return type

[**InlineResponse2006**](InlineResponse2006.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="listDatasets"></a>
# **listDatasets**
> InlineResponse2007 listDatasets(authorization, accept)

Retrieve List of Datasets

This endpoint allows users to retrieve a list of available datasets.

### Example
```javascript
import {QuasaraApi} from 'quasara_api';

let apiInstance = new QuasaraApi.DATASETOBJECTMANAGEMENTApi();
let authorization = "authorization_example"; // String | 
let accept = "application/json"; // String | 

apiInstance.listDatasets(authorization, accept, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **String**|  | 
 **accept** | **String**|  | [default to application/json]

### Return type

[**InlineResponse2007**](InlineResponse2007.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="listModels"></a>
# **listModels**
> InlineResponse2008 listModels(authorization, accept)

Retrieve List of Models

This endpoint allows users to retrieve a list of available models.

### Example
```javascript
import {QuasaraApi} from 'quasara_api';

let apiInstance = new QuasaraApi.DATASETOBJECTMANAGEMENTApi();
let authorization = "authorization_example"; // String | 
let accept = "application/json"; // String | 

apiInstance.listModels(authorization, accept, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **String**|  | 
 **accept** | **String**|  | [default to application/json]

### Return type

[**InlineResponse2008**](InlineResponse2008.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="updateTags"></a>
# **updateTags**
> InlineResponse2011 updateTags(body, authorization, accept, contentType)

Update Tags for Dataset

This endpoint allows users to update the tags associated with a specific dataset.

### Example
```javascript
import {QuasaraApi} from 'quasara_api';

let apiInstance = new QuasaraApi.DATASETOBJECTMANAGEMENTApi();
let body = new QuasaraApi.UpdatetagsBody(); // UpdatetagsBody | 
let authorization = "authorization_example"; // String | 
let accept = "application/json"; // String | 
let contentType = "application/json"; // String | 

apiInstance.updateTags(body, authorization, accept, contentType, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**UpdatetagsBody**](UpdatetagsBody.md)|  | 
 **authorization** | **String**|  | 
 **accept** | **String**|  | [default to application/json]
 **contentType** | **String**|  | [default to application/json]

### Return type

[**InlineResponse2011**](InlineResponse2011.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

