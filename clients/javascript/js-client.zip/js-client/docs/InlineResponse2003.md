# QuasaraApi.InlineResponse2003

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**dataAnalyticsId** | **String** |  | [optional] 
**type** | **String** |  | [optional] 
**algorithm** | **String** |  | [optional] 
**isCompleted** | **Boolean** |  | [optional] 
**dimensionSize** | **Number** |  | [optional] 
**dimensionalityReductionAlgorithm** | **String** |  | [optional] 
**scoreThreshold** | **Number** |  | [optional] 
**contamination** | **Number** |  | [optional] 
**analysisDetails** | [**[FetchdataanalyticsinfoAnalysisDetails]**](FetchdataanalyticsinfoAnalysisDetails.md) |  | [optional] 
