# QuasaraApi.InlineResponse4015

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**error** | **String** | Description of the error due to invalid credentials. | [optional] 
