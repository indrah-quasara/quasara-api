# QuasaraApi.FetchdataanalyticsinfoBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**tagId** | **String** | The unique identifier for the tag. | [optional] 
