# QuasaraApi.InlineResponse4002

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**error** | **String** |  | [optional] 
